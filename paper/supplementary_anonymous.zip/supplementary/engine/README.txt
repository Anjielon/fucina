engine_vs_base_521a64cd.diff   the fork's own changes (19 files) against upstream 521a64cd01979bb5b1a466152c576a9d809b068d
engine_vs_merge_8fe90e1f.diff  the same tree against upstream 8fe90e1fbfc065f17a0b233c9df239423cd24a75 (src ggml tools gguf-py include common)
FILES_CHANGED.txt                  the 19 files
Apply the first one to a checkout of 521a64cd01979bb5b1a466152c576a9d809b068d with: patch -p1 < engine_vs_base_521a64cd.diff
See ../README.md, section "engine/".
