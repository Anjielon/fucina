#!/bin/bash
# Banco HellaSwag/Winogrande RIPRENDIBILE — nasce dalla domanda del committente
# (31/8 22:26): «non si possono riprendere dal punto lasciato?».
#
# `llama-perplexity` NON sa riprendere: `--hellaswag-tasks N` sceglie N compiti
# a caso e ricomincia sempre da zero. Ma il corpus ha una struttura regolare —
# HellaSwag 6 righe per compito (contesto · indice giusto · 4 finali),
# Winogrande una riga CSV per compito — quindi si puo' SPEZZARE.
#
# Ogni pezzo e' una corsa breve e indipendente. Se il banco si ferma, riparte
# dal primo pezzo non ancora fatto: si perde al massimo un pezzo, non tutto.
# I punteggi si sommano: l'accuratezza e' giusti/totali, additiva per costruzione.
#
# Uso:  banco_a_pezzi.sh <modello.gguf> <nome> [compiti_per_pezzo]
set -u
M="${1:?modello richiesto}"
NOME="${2:?nome richiesto}"
PASSO="${3:-500}"

B=${LLAMA_BIN:-./bin}
CORPUS=${CORPUS:-./hellaswag_val_full.txt}
PEZZI=${PIECES:-./hellaswag_pieces}
OUT=${OUT_DIR:-./results}/pezzi_${NOME}
L=${OUT_DIR:-./results}/banco_pezzi_${NOME}.log
RIGHE_PER_COMPITO=6
SOGLIA_MIB=12000

mkdir -p "$PEZZI" "$OUT"
exec >>"$L" 2>&1
echo "══ $(date '+%d/%m %H:%M:%S') $NOME · $(basename "$M") · $PASSO compiti per pezzo"

# 1. taglia il corpus una volta sola, a confini di compito
if [ ! -f "$PEZZI/.pronto" ]; then
  tot=$(( $(wc -l < "$CORPUS") / RIGHE_PER_COMPITO ))
  echo "── taglio $tot compiti in pezzi da $PASSO"
  i=0
  while [ $i -lt $tot ]; do
    n=$PASSO; [ $((i + n)) -gt $tot ] && n=$((tot - i))
    sed -n "$((i * RIGHE_PER_COMPITO + 1)),$(((i + n) * RIGHE_PER_COMPITO))p" \
        "$CORPUS" > "$PEZZI/$(printf '%05d' $i).txt"
    i=$((i + n))
  done
  touch "$PEZZI/.pronto"
  echo "   $(ls "$PEZZI"/*.txt | wc -l) pezzi pronti"
fi

spazio() { awk '$1=="MemAvailable:"||$1=="SwapFree:"{s+=$2}END{printf "%d",s/1024}' /proc/meminfo; }

# 2. macina i pezzi non ancora fatti
for p in "$PEZZI"/*.txt; do
  b=$(basename "$p" .txt)
  e="$OUT/$b.log"
  # ⛔ 31/8 23:20: il controllo era `grep "Final HellaSwag"` — riga che
  #    llama-perplexity NON STAMPA MAI per HellaSwag (la stampa per Winogrande).
  #    Risultato: nessun pezzo risultava fatto e il banco li rifaceva in eterno.
  #    Un controllo che non puo' RIUSCIRE e' rotto quanto uno che non puo' fallire.
  #    Il segnale vero: l'ultima riga numerata ha come primo campo il numero di
  #    compiti del pezzo.
  atteso=$(( $(wc -l < "$p") / RIGHE_PER_COMPITO ))
  fatti=$(grep -E "^[0-9]+\s" "$e" 2>/dev/null | tail -1 | awk "{print \$1}")
  [ "${fatti:-0}" = "$atteso" ] && { echo "── $b gia' fatto ($fatti compiti)"; continue; }
  for _ in $(seq 1 90); do [ "$(spazio)" -ge $SOGLIA_MIB ] && break; sleep 60; done
  if [ "$(spazio)" -lt $SOGLIA_MIB ]; then
    echo "   ⛔ $(date +%H:%M:%S) niente memoria per $b: mi fermo qui, riprendero' da questo pezzo"
    exit 2
  fi
  n=$(( $(wc -l < "$p") / RIGHE_PER_COMPITO ))
  echo "── $b ($n compiti) $(date +%H:%M:%S) · spazio $(spazio) MiB"
  # ⛔ 18/9 05:28 — su ODINO-397B i compiti WikiHow (dal confine 3500 in poi)
  # costano 7.8s/compito contro i 4.2s di ActivityNet (contesti piu' lunghi):
  # un pezzo da 500 supera i 3600s e viene TAGLIATO A META' dal timeout,
  # in silenzio (lo script passa al pezzo dopo, quello incompleto non viene
  # mai ripreso finche' non si rilancia da capo). Trovato sul pezzo 03500,
  # fermo a 460/500. Alzato a 7200s (margine ~2x sul ritmo piu' lento misurato).
  # ⭐ 18/9: ODINO_P2_COMP passa al motore la compensazione di volume
  #    caldi/freddi (candidato trovato in casa, testato +4.2 punti su
  #    caldi28-hessbf16). Se non impostata, comportamento invariato.
  # ⛔ un token da espansione ${var:+...} NON e' riconosciuto da bash come
  #    prefisso di assegnazione (lo e' solo se scritto letteralmente
  #    NOME=valore nel sorgente) — con set -u finiva eseguito come comando,
  #    "comando non trovato". `env` invece prende NOME=valore come un
  #    normale argomento stringa, espanso o no che sia.
  LD_LIBRARY_PATH=$B nice -n 5 timeout 7200 env ${ODINO_P2_COMP:+ODINO_P2_COMP="$ODINO_P2_COMP"} "$B/llama-perplexity" --model "$M" \
      -ngl 999 --ctx-size 4096 --threads 8 --hellaswag --hellaswag-tasks "$n" \
      --file "$p" > "$e" 2>&1
  grep -oE "Final HellaSwag score\(.*" "$e" | sed 's/^/   /'
done

# 3. somma i pezzi — separando le DUE META' del corpus
#    ⛔ 1/9 00:21: HellaSwag val e' DUE corpora incollati. Fino al compito ~3500
#    sono descrizioni di video ActivityNet (188 categorie granulari); da 3500 in
#    poi sono istruzioni WikiHow (19 categorie larghe). Un modello va ~14 punti
#    MEGLIO sulla seconda meta'. Un totale solo nasconde la dissociazione.
python3 - "$OUT" <<'PY'
import pathlib, re, sys
import math
GIUNZIONE = 3500          # dove ActivityNet finisce e WikiHow comincia
parti = {"activitynet": [0, 0], "wikihow": [0, 0], "TOTALE": [0, 0]}
for f in sorted(pathlib.Path(sys.argv[1]).glob("*.log")):
    ultime = [r for r in f.read_text(errors="replace").splitlines() if re.match(r"^\d+\s", r)]
    if not ultime:
        continue
    c = ultime[-1].split()
    n, acc = int(c[0]), float(c[1].rstrip("%"))
    g = round(n * acc / 100)
    dove = "activitynet" if int(f.stem) < GIUNZIONE else "wikihow"
    for k in (dove, "TOTALE"):
        parti[k][0] += g
        parti[k][1] += n
for k, (g, t) in parti.items():
    if not t:
        continue
    p = 100 * g / t
    e = math.sqrt(p / 100 * (1 - p / 100) / t) * 100
    print(f"   {k:12} {g:5}/{t:5} = {p:7.4f}% ± {e:.4f}")
PY
echo "🏁 $(date +%H:%M:%S) $NOME"
