#!/usr/bin/env python3
"""Split a llama.cpp multiple-choice binary (the format read by
`llama-perplexity --multiple-choice`) into sequential pieces of N tasks.

Format (from tools/perplexity/perplexity.cpp):
    uint32 n_task
    uint32 task_pos[n_task]      byte offset of each task from the file start
    n_task serialised tasks      (question, mc1 answers + labels, mc2 block)

Each piece is a valid file of the same format; tasks keep their order, so the
per-item outcomes of the pieces are those of the whole file scored in order.

Usage:
    python3 split_multiple_choice.py IN.bin OUT_PREFIX N
    -> OUT_PREFIX_00000.bin, OUT_PREFIX_02000.bin, ...  (N = 2000)
"""
import struct
import sys
from pathlib import Path


def read_tasks(path: Path) -> list[bytes]:
    data = path.read_bytes()
    (n,) = struct.unpack_from("<I", data, 0)
    pos = list(struct.unpack_from(f"<{n}I", data, 4))
    pos.append(len(data))
    return [data[pos[i]:pos[i + 1]] for i in range(n)]


def write_tasks(tasks: list[bytes], path: Path) -> None:
    header = 4 + 4 * len(tasks)
    offsets, cur = [], header
    for t in tasks:
        offsets.append(cur)
        cur += len(t)
    out = struct.pack("<I", len(tasks)) + struct.pack(f"<{len(tasks)}I", *offsets)
    path.write_bytes(out + b"".join(tasks))


def main() -> None:
    if len(sys.argv) != 4:
        print(__doc__, file=sys.stderr)
        sys.exit(1)
    src, prefix, step = Path(sys.argv[1]), sys.argv[2], int(sys.argv[3])
    tasks = read_tasks(src)
    for start in range(0, len(tasks), step):
        piece = tasks[start:start + step]
        out = Path(f"{prefix}_{start:05d}.bin")
        write_tasks(piece, out)
        print(f"{out}: tasks {start}..{start + len(piece) - 1} ({len(piece)})")


if __name__ == "__main__":
    main()
