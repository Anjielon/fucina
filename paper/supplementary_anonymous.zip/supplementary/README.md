# Supplementary material — "Depth, Not Fidelity: What Decides Whether a Ternary Correction Helps a Mixture-of-Experts"

Anonymous submission. Everything in this archive is either code, converted
public benchmark data, or raw logs; no model weights are included (the two
public 397B files are named in the paper and the ternary file's forge is here).
`SHA256SUMS` covers every file in the archive.

## Layout

| path | what |
|---|---|
| `engine/` | the modified llama.cpp used for **every** number in the paper, as two diffs (see below) |
| `forge/` | the ternary forge and analysis scripts (Sections 2–5, 8 of the paper) |
| `benchmarks/` | the multiple-choice converter, the `.bin` files it produced, the HellaSwag pieces, and the scripts that cut and run them (Section 6) |
| `logs/` | the raw `llama-perplexity` logs of the cloud benchmark runs, 38 per file, plus the discarded runs (Section 6.1) |
| `SHA256SUMS` | `sha256sum -c SHA256SUMS` from this directory verifies the archive |

## engine/ — the two-plane llama.cpp fork

The fork's git history was not preserved (the binary reports `commit
unknown`). The upstream commit it was branched from was identified after the
fact by matching every file the fork does **not** modify against the history
of `ggml-org/llama.cpp` (blob-exact `git hash-object` match): all of them match
the tree of

    521a64cd01979bb5b1a466152c576a9d809b068d   (2026-08-20, "ui: Stores split refactor (#27240)")

and a file changed by the next upstream commit is in the fork at its
pre-change state. Relative to that base the fork changes **19 files**
(`engine/FILES_CHANGED.txt`): the TQ1_0 Vulkan kernels and shaders under
`ggml/src/ggml-vulkan/`, the two-plane loader and graph (`src/llama-arch.*`,
`src/llama-graph.*`, `src/llama-hparams.h`, `src/llama-model.*`,
`src/models/qwen35moe.cpp`), an activation-dump facility in
`common/debug.cpp` (used for the Hessian capture, not by any benchmark run),
and `tests/test-backend-ops.cpp`.

Two diffs are provided, with their SHA-256 in `SHA256SUMS`:

- `engine/engine_vs_base_521a64cd.diff` — the fork's own changes against the
  commit it was branched from. **Apply this one** to rebuild the engine:

      git clone https://github.com/ggml-org/llama.cpp && cd llama.cpp
      git checkout 521a64cd01979bb5b1a466152c576a9d809b068d
      patch -p1 < /path/to/engine_vs_base_521a64cd.diff
      cmake -B build -DGGML_VULKAN=ON && cmake --build build -j

- `engine/engine_vs_merge_8fe90e1f.diff` — the same tree against the upstream
  merge commit of the single-plane TQ1_0 Vulkan path
  (`8fe90e1fbfc065f17a0b233c9df239423cd24a75`, 2026-09-07), restricted to
  `src/ ggml/ tools/ gguf-py/ include/ common/`. It is large because
  upstream moved on between the two commits; it is included because the paper
  refers to the merge commit. The relationship between the two: the
  single-plane TQ1_0 Vulkan path that the fork carries is now in upstream
  llama.cpp (that merge commit); the second plane (`_exps2` tensors, `expert_count2` metadata, per-layer switches) exists
  only in the fork, and a two-plane file does not load on upstream
  (`wrong number of tensors; expected 1278, got 1098` on the 397B file).

**State of the tree.** The diffs are of the source tree as built for the
cloud benchmark runs (2026-09-19). The per-layer anatomy of Sections 3–5 was
run on the same fork at earlier dates; the two-plane loader in `src/` is the
same code (last changed 2026-08-28). One file, `src/llama-model.cpp`, carries
a later change (2026-09-18): an environment-guarded switch
(`LLAMA_NO_MMAP_PREFETCH`) that disables mmap prefetch when set; it is not
set in any run reported in the paper. Runtime switches that matter for the
paper: `ODINO_P2_LAYERS=LO-HI` (and `ODINO_P2_{UP,GATE,DOWN}_LAYERS`) restrict
the second plane to a layer band; `ODINO_NO_P2` (and per-projection variants)
disable it; with none set the second plane is applied on every layer whose
`_exps2` tensors exist (Section 6.2 of the paper).

**Redaction.** For double-blind review, one project-name string that appears
in comments and in three debugging environment-variable names
(`*_DUMP_DIR`, `*_DUMP_FILTER`, `*_DUP_IDS`, in `common/debug.cpp`,
`src/llama-graph.h` and `tests/test-backend-ops.cpp`) was replaced by
`PROJECT` in both diffs. No other edit was made; the affected code is the
activation-dump facility and a test helper, not a code path of any benchmark
run. Comments in the fork are partly in a language other than English; they
were left as written.

## forge/ — the ternary forge

| file | what it does | paper |
|---|---|---|
| `forge.py`, `forge_gguf.py`, `forge_from_bf16.py` | the quantizer: builds the ternary file from bf16 or from an existing GGUF | §2 |
| `two_planes.py` | the second ternary plane on the hottest experts — the corrective mechanism under study | §3 |
| `tq1_pack.py`, `tq1_b160.py` | TQ1_0 plane packing (1.69 bits/weight for the format itself) | §2 |
| `ternary_gpu.py` | GPU-side reconstruction used to measure weight and output error | §3 |
| `selective_rollback.py`, `promote_tensors.py`, `strip_tensors.py`, `transplant_tensors.py` | per-layer / per-projection surgery on files; the strip tool of §5; the transplant that built v3.4a (§6.2) | §3, §5, §6.2 |
| `build_hessians.py` | activation second-moment capture (calibration) | §2, §4 |
| `correction_magnitude.py`, `routing_concentration.py`, `selection_divergence.py`, `routing_agreement.py`, `projected_error.py`, `permutation_check.py`, `hot_coverage.py`, `impact_rank_odino.py` | the pre-registered refutations | §4 |
| `routing_margin_distribution.py` | the top-k routing margin distribution | §8 |
| `paired_compare.py` | the paired logit-level comparison (mean Δp) | §5 |
| `damage_shape.sh`, `layer_damage_profile.sh`, `layer_band_search.sh`, `projection_decomposition.sh`, `tools_routing_flip.sh` | drivers that reproduce the per-layer sweeps | §3, §4, §5 |
| `experiments/` | the trellis (TCQ1_7) pre-test of the Limitations section and related studies | §10 |
| `docs/LESSONS.md`, `docs/RESULTS.md` | the project log: pre-registered predictions, every measurement with its conditions | §2, §4 |
| `docs/DESIGN.md`, `docs/TCQ1_7_DESIGN.md`, `docs/TQ1_B160_DESIGN.md` | design notes | — |

Python 3.10+, `numpy`, `gguf`. Each script has `--help`.

## benchmarks/ — Section 6

- `converti_multiple_choice.py` — converts the public multiple-choice
  releases (`datasets` 5.0.0; sources and revisions in Table 2 of the paper)
  into llama.cpp's binary multiple-choice format, with the prompt templates
  stated in §6.1. Its SHA-256 is the one printed in the paper.
- `split_multiple_choice.py` — splits a `.bin` into sequential pieces of N
  tasks (the pieces below are byte-identical to
  `split_multiple_choice.py X_test.bin X 2000`).
- `mc_bins/` — the converted files: whole corpora (`*_test.bin`, `piqa_test.bin`
  is the declared 1,000-item subset) and the 2,000-task pieces that were
  actually queued (`mmlu_00000.bin` … `mmlu_14000.bin`, `boolq_0*.bin`,
  `arc_easy_0*.bin`). SHA-256 of each in `SHA256SUMS`.
- `hellaswag_pieces/` — the 21 sequential pieces of `hellaswag_val_full.txt`
  (the file llama.cpp's `scripts/get-hellaswag.sh` downloads; 500 tasks =
  3,000 lines each, the last 42 tasks); their concatenation in order is the
  whole file. SHA-256 of the whole file: see `benchmarks/CORPORA.txt`.
- `hellaswag_pieces.sh` — the script that cuts the pieces and runs them
  (paths normalised; `LLAMA_BIN`, `CORPUS`, `PIECES`, `OUT_DIR`).
- `CORPORA.txt` — SHA-256 of the public corpus files used
  (`hellaswag_val_full.txt`, `winogrande-debiased-eval.csv`, `wiki.test.raw`).

The five commands of §6.1, with `MODEL` the GGUF file and no other flag
(the fifth only when this archive includes TruthfulQA MC1):

    llama-perplexity -m MODEL -ngl 999 -c 4096 --hellaswag --hellaswag-tasks 100000 -f PIECE.txt
    llama-perplexity -m MODEL -ngl 999 -c 8192 -np 8 --multiple-choice --multiple-choice-tasks 100000 -f FILE.bin
    llama-perplexity -m MODEL -ngl 999 -c 4096 --winogrande --winogrande-tasks 100000 -f winogrande-debiased-eval.csv
    llama-perplexity -m MODEL -ngl 999 -c 4096 -b 2048 -f wiki.test.raw
    llama-perplexity -m MODEL -ngl 999 -c 3328 -np 13 -b 256 -ub 256 --multiple-choice --multiple-choice-tasks 100000 -f FILE.bin

## logs/ — the raw cloud logs

One directory per file, 38 logs each plus, when this archive was generated
with `INCLUDI_TRUTHFULQA=1`, a 39th (`mc16_truthfulqa_mc1_test.log`, Table 4),
named as in the paper:

| directory | file |
|---|---|
| `logs/ODINO-v3.4a/` | ODINO-397B v3.4a, 88.17 GiB (second plane applied on all 60 layers: no environment variable set) |
| `logs/IQ1_M/` | `bartowski/Ornith-1.5-397B-GGUF`, folder IQ1_M, 85.09 GiB |
| `logs/Tony-v4-B/` | the single-plane 35B file, 15.47 GiB (not yet public) |
| `logs/APEX-MTP-I-Compact/` | `mudler/Ornith-1.5-35B-A3B-APEX-MTP-GGUF`, APEX-MTP-I-Compact, 16.24 GiB |

Per directory: `hs_00000.log` … `hs_10000.log` (21 HellaSwag pieces),
`mc_mmlu_00000.log` … `mc_mmlu_14000.log` (8), `mc_boolq_00000.log`,
`mc_boolq_02000.log`, `mc_arc_easy_00000.log`, `mc_arc_easy_02000.log`,
`mc_arc_challenge_test.log`, `mc_piqa_test.log`, `mc_openbookqa_test.log`,
`wg_winogrande.log`, `ppl_wikitext.log`. The logs are the engine's standard
output; they do not repeat the model path, which is fixed by the directory.
A multiple-choice log is valid when its last scored task number equals the
task count in its header; the HellaSwag pieces score every task of the piece;
the per-item outcomes used for the paired tests are read from the cumulative
accuracy rows (multiple choice, HellaSwag) and from the per-item rows
(Winogrande). If present, `mc16_truthfulqa_mc1_test.log` is TruthfulQA MC1
(817 items, lm-eval's fixed six-shot preamble, up to 13 options per
question); it was run with `-np 13 -c 3328 -b 256 -ub 256` to leave headroom
for the 397B file's compute buffers (§6.1), not with the four commands above.

`logs/discarded/` holds the runs that were discarded and why (in the file
name): `formatov1_*` — an earlier BoolQ/MMLU/PIQA/OpenBookQA prompt template
without the `Question:`/`Answer:` scaffold (the run that put the ternary 397B
file below chance on BoolQ, §6.1); `np4_*` — ARC runs with the default
`-np 4`, which stop at the first five-option item while reporting a result;
`doppione_*`, `nomefile_*` — a duplicate and a mis-named run; when
`INCLUDI_TRUTHFULQA=1`, also one discarded TruthfulQA attempt per file
(`oom_*`, `rscache_*`, `bloccato_np16_*` — an out-of-memory run, a
result-cache failure, and an earlier `-np 16` setting that stalled). The
discarded logs do not record which file they were run on.

## What is deliberately not here

- **Model weights.** The two 397B files are public (named in §6.2); the 35B
  file of Table 4 is not yet published (Limitations).
- **The internal task suite** (§7): aggregate results only, as stated in the
  paper; no reproducibility claim is made on it.
- **The rotated/other experimental types** added to the fork after the
  benchmark runs; they are not part of the engine used for the paper.
